/* Pontuação por treinador: (1) séries de estrelas/luas de uso, (2) pontos com base e etiqueta do último lançamento.
   Tudo fica no aparelho (localStorage), funciona 100% offline. */
(()=>{'use strict';
 const KEY='tf_pontos_v1';
 const $=(s,r=document)=>r.querySelector(s);
 const el=(t,txt,cls)=>{const n=document.createElement(t);if(txt!==undefined)n.textContent=txt;if(cls)n.className=cls;return n;};
 const say=t=>{try{toast(t);}catch(_){}};
 const trainers=()=>{try{return (typeof db!=='undefined'&&db.personagens)||[];}catch(_){return [];}};

 /* ---------- armazenamento ---------- */
 let data={t:{}};
 try{const raw=localStorage.getItem(KEY);if(raw){const d=JSON.parse(raw);if(d&&d.t)data=d;}}catch(_){}
 let saveFail=false;
 function save(){try{localStorage.setItem(KEY,JSON.stringify(data));saveFail=false;}catch(e){if(!saveFail)say('⚠️ Não consegui salvar a pontuação (memória cheia?).');saveFail=true;}}
 const defStars=()=>({total:10,used:0,icon:'star',on:'#ffc21a',off:'#4a5560',size:26,resetHour:-1,lastReset:Date.now(),label:'Uso'});
 const defPts=()=>({base:100,items:[],hist:[],plus:'#2ecc71',minus:'#e74c3c',custom:''});
 function T(id){if(!data.t[id])data.t[id]={stars:defStars(),pts:defPts()};const o=data.t[id];if(!o.stars)o.stars=defStars();if(!o.pts)o.pts=defPts();return o;}
 const total=o=>o.pts.hist.reduce((s,h)=>s+h.delta,+o.pts.base||0);
 const fmt=n=>{const r=Math.round(n*100)/100;return (r>0?'+':'')+String(r).replace('.',',');};
 const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);

 /* ---------- reset por horário ---------- */
 /* Se passou da hora escolhida (ex.: 06:00) desde o último reset, zera as estrelas usadas. */
 function lastDue(hour){const n=new Date();const d=new Date(n.getFullYear(),n.getMonth(),n.getDate(),hour,0,0,0);if(d>n)d.setDate(d.getDate()-1);return d.getTime();}
 function autoReset(){let changed=false;for(const id in data.t){const s=data.t[id].stars;if(s.resetHour>=0&&s.resetHour<=23&&(s.lastReset||0)<lastDue(s.resetHour)){s.used=0;s.lastReset=Date.now();changed=true;}}if(changed)save();return changed;}

 /* ---------- treinador menos usado ---------- */
 function leastUsed(){const l=trainers();if(!l.length)return null;let best=null,bs=Infinity;l.forEach(p=>{const s=T(p.id).stars;const r=s.total>0?s.used/s.total:0;if(r<bs){bs=r;best=p;}});return best;}


 /* ---------- ícones desenhados (SVG): nada de emoji parado ---------- */
 const ICONS={half:'Meia lua e meia sombra',eclipse:'Eclipse',crescent:'Lua crescente',moon:'Lua cheia',star:'Estrela',crown:'Coroa',swords:'Espadas',sword:'Espada',fan:'Leque',shield:'Escudo',bolt:'Raio',diamond:'Diamante',flame:'Chama',sun:'Sol',drop:'Gota',heart:'Coração'};
 const ANIMS={pulse:'Brilho pulsando',spin:'Girar',float:'Flutuar',sway:'Balançar',flicker:'Chama tremendo',rainbow:'Arco-íris',shine:'Cintilar',none:'Sem animação'};
 const hex=c=>/^#[0-9a-f]{6}$/i.test(c)?c:'#ffc21a';
 function svgIcon(type,lit,on,off,size){
  on=hex(on);off=hex(off);const BG='#172830',D='#0b0f14';let b='';const c=lit?on:off;
  if(type==='star'){b='<polygon points="12,2 15,8.8 22,9.6 16.8,14.4 18.4,21.6 12,18 5.6,21.6 7.2,14.4 2,9.6 9,8.8" stroke-linejoin="round" stroke-width="1.6" stroke="'+(lit?on:off)+'" fill="'+(lit?on:off)+'"/>'+(lit?'<polygon points="12,5.2 13.6,9.4 17.8,9.9 14.7,12.7 15.6,17 12,14.9" fill="#fff" opacity=".35"/>':'');}
  else if(type==='eclipse'){b=lit?'<circle cx="12" cy="12" r="10.6" fill="none" stroke="'+on+'" stroke-width="1.2" opacity=".55"/><circle cx="12" cy="12" r="9" fill="'+on+'"/><circle cx="14.6" cy="9.4" r="7.9" fill="'+D+'"/>':'<circle cx="12" cy="12" r="9" fill="'+off+'"/><circle cx="14.6" cy="9.4" r="7.9" fill="'+D+'" opacity=".8"/>';}
  else if(type==='half'){b='<path d="M12 3A9 9 0 0 0 12 21Z" fill="'+(lit?on:off)+'"/><path d="M12 3A9 9 0 0 1 12 21Z" fill="'+D+'"/><circle cx="12" cy="12" r="9" fill="none" stroke="'+(lit?on:off)+'" stroke-width="1.4"/>';}
  else if(type==='crescent'){b='<circle cx="12" cy="12" r="9.2" fill="'+(lit?on:off)+'"/><circle cx="16.2" cy="9.6" r="8" fill="'+BG+'"/>';}
  else if(type==='heart'){b='<path d="M12 21C5 15.5 2.5 12 2.5 8.4A4.9 4.9 0 0 1 12 6.5a4.9 4.9 0 0 1 9.5 1.9C21.5 12 19 15.5 12 21Z" fill="'+(lit?on:off)+'"/>'+(lit?'<ellipse cx="8" cy="8.2" rx="2" ry="1.3" fill="#fff" opacity=".35"/>':'');}
  else if(type==='moon'){b='<circle cx="12" cy="12" r="9.5" fill="'+c+'"/>'+(lit?'<circle cx="9" cy="9" r="2" fill="'+D+'" opacity=".14"/><circle cx="15" cy="14" r="2.6" fill="'+D+'" opacity=".12"/><circle cx="9.5" cy="15.5" r="1.3" fill="'+D+'" opacity=".12"/>':'');}
  else if(type==='crown'){b='<path d="M3 18L2 7l5.5 4.5L12 4l4.5 7.5L22 7l-1 11z" fill="'+c+'"/><rect x="3" y="19.5" width="18" height="2.6" rx="1.1" fill="'+c+'"/>'+(lit?'<circle cx="12" cy="13.5" r="1.4" fill="#fff" opacity=".6"/><circle cx="7" cy="14.5" r="1.1" fill="#fff" opacity=".45"/><circle cx="17" cy="14.5" r="1.1" fill="#fff" opacity=".45"/>':'');}
  else if(type==='sword'||type==='swords'){const SW='<g stroke="'+c+'" fill="'+c+'" stroke-linecap="round"><path d="M20.8 3.2l-.3 3.6-9.3 9.3-3.3-3.3 9.3-9.3z" stroke-width=".6" stroke-linejoin="round"/><path d="M6.6 11.8l5.6 5.6" stroke-width="2.4" fill="none"/><path d="M8.8 15.2L4.2 19.8" stroke-width="2.6" fill="none"/><circle cx="3.6" cy="20.4" r="1.5" stroke="none"/></g>'+(lit?'<path d="M18.6 4.8L11 12.4" stroke="#fff" stroke-width=".9" opacity=".5" fill="none"/>':'');b=type==='sword'?SW:SW+'<g transform="translate(24 0) scale(-1 1)">'+SW+'</g>';}
  else if(type==='fan'){b='<path d="M12 21.5L2 9.2a15.5 15.5 0 0 1 20 0z" fill="'+c+'"/><path d="M12 21.5L6.5 7.2M12 21.5L12 6.2M12 21.5L17.5 7.2" stroke="'+D+'" stroke-opacity="'+(lit?.45:.6)+'" stroke-width=".9" fill="none"/><rect x="10.6" y="19.6" width="2.8" height="3" rx="1.2" fill="'+(lit?'#fff':c)+'" opacity="'+(lit?.55:1)+'"/>';}
  else if(type==='shield'){b='<path d="M12 2l8.5 3v6.2c0 5-3.6 9-8.5 10.8-4.9-1.8-8.5-5.8-8.5-10.8V5z" fill="'+c+'"/>'+(lit?'<path d="M12 5l5.6 2v4.2c0 3.4-2.3 6.2-5.6 7.8z" fill="#fff" opacity=".22"/>':'');}
  else if(type==='bolt'){b='<path d="M13.5 2L4.5 13.5h6L9.5 22l9-12h-6z" fill="'+c+'" stroke="'+c+'" stroke-width=".8" stroke-linejoin="round"/>';}
  else if(type==='diamond'){b='<path d="M6.5 3h11l4.5 6L12 21.5 2 9z" fill="'+c+'"/>'+(lit?'<path d="M2 9h20M9 3l-2 6 5 12.5M15 3l2 6-5 12.5" stroke="#fff" stroke-opacity=".5" stroke-width=".8" fill="none"/>':'');}
  else if(type==='flame'){b='<path d="M12.5 2c.6 3.6 5.5 5.6 5.5 11.2a6 6 0 0 1-12 0c0-2.8 1.4-4.4 2.8-6 .3 1.8 1.2 2.6 2.2 2.8C10.4 7.4 11 4.6 12.5 2z" fill="'+c+'"/>'+(lit?'<path d="M12 21a3.4 3.4 0 0 1-3.4-3.4c0-2 1.6-3 3.4-5.6 1.8 2.6 3.4 3.6 3.4 5.6A3.4 3.4 0 0 1 12 21z" fill="#fff" opacity=".4"/>':'');}
  else if(type==='sun'){b='<circle cx="12" cy="12" r="5" fill="'+c+'"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" stroke="'+c+'" stroke-width="2" stroke-linecap="round" fill="none"/>';}
  else if(type==='drop'){b='<path d="M12 2.5C8 8 5.5 11 5.5 14.5a6.5 6.5 0 0 0 13 0C18.5 11 16 8 12 2.5z" fill="'+c+'"/>'+(lit?'<ellipse cx="9.2" cy="14.5" rx="1.3" ry="2.4" fill="#fff" opacity=".4"/>':'');}
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="'+size+'" height="'+size+'" aria-hidden="true">'+b+'</svg>';
 }
 function icEl(type,lit,on,off,size,anim,half,i){const e=el('span',null,'tp-ic'+(lit?' on a-'+(anim||'pulse'):''));e.style.setProperty('--c',hex(on));e.style.setProperty('--d',((i||0)*.12).toFixed(2)+'s');e.style.width=size+'px';e.style.height=size+'px';
  if(!ICONS[type]){e.textContent=type||'⭐';e.style.cssText+=';font-size:'+size+'px;line-height:1;'+(lit?'':'opacity:.35;filter:grayscale(1)');return e;}
  if(lit&&half&&type!=='half'){e.style.position='relative';e.innerHTML=svgIcon(type,false,on,off,size)+'<span class="tp-lay">'+svgIcon(type,true,on,off,size)+'</span>';}else e.innerHTML=svgIcon(type,lit,on,off,size);return e;}
 /* ---------- interface ---------- */
 const style=el('style');style.textContent=`
 #tf-pontos[hidden]{display:none!important}
 #tf-pontos{position:fixed;inset:0;z-index:1000000;background:#10191f;color:#eff7fa;display:flex;flex-direction:column;font:15px system-ui,sans-serif;overflow:hidden}
 #tf-pontos *{box-sizing:border-box}
 #tf-pontos button{background:#233840;color:#ecfffb;border:1px solid #41606b;border-radius:12px;padding:10px 12px;font:inherit;min-height:42px}
 #tf-pontos button.pri{background:#145946;border-color:#49ddaf}
 #tf-pontos input,#tf-pontos select{font:inherit;color:#f5fbff;background:#16262e;border:1px solid #3d5965;border-radius:10px;padding:9px;min-width:0;max-width:100%}
 #tf-pontos input[type=color]{padding:2px;width:46px;height:40px}
 #tf-pontos input[type=number]{width:80px}
 .tp-h{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#19333c;padding-top:max(10px,env(safe-area-inset-top))}
 .tp-h strong{flex:1;font-size:17px}
 .tp-b{flex:1;overflow:auto;padding:14px calc(14px + env(safe-area-inset-right)) calc(24px + env(safe-area-inset-bottom)) 14px}
 .tp-c{border:1px solid #34505b;border-radius:16px;background:#172830;padding:13px;margin:12px 0}
 .tp-c h3{margin:0 0 8px;font-size:16px}
 .tp-r{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:7px 0}
 .tp-r label{display:flex;align-items:center;gap:5px;font-size:13px;color:#b3cbd1}
 .tp-stars{display:flex;flex-wrap:wrap;gap:3px;margin:8px 0;line-height:1}
 .tp-tag{display:inline-block;border-radius:999px;padding:5px 13px;font-weight:700;color:#fff}
 .tp-big{font-size:34px;font-weight:800}
 .tp-hist{display:flex;align-items:center;gap:8px;padding:6px 0;border-top:1px solid #2a424c;font-size:14px}
 .tp-hist span.d{font-weight:700;min-width:56px}
 .tp-hist img{width:28px;height:28px;object-fit:cover;border-radius:6px}
 .tp-it{display:inline-flex;align-items:center;gap:5px}
 #tc-pontos-btn{margin:4px}
 .tp-ic{display:inline-block;line-height:0;cursor:pointer;-webkit-tap-highlight-color:transparent}
 .tp-ic svg{display:block}
 .tp-ic{transition:filter .25s}
 .tp-lay{position:absolute;inset:0;clip-path:inset(0 50% 0 0)}
 .tp-ic.on{filter:drop-shadow(0 0 4px var(--c))}
 .tp-ic.on.a-pulse{animation:tpPulse 2.4s ease-in-out var(--d,0s) infinite}
 .tp-ic.on.a-spin{animation:tpSpin 7s linear var(--d,0s) infinite}
 .tp-ic.on.a-float{animation:tpFloat 2.8s ease-in-out var(--d,0s) infinite}
 .tp-ic.on.a-sway{animation:tpSway 2.2s ease-in-out var(--d,0s) infinite}
 .tp-ic.on.a-flicker{animation:tpFlick 1.3s ease-in-out var(--d,0s) infinite}
 .tp-ic.on.a-rainbow{animation:tpRainbow 4s linear var(--d,0s) infinite}
 .tp-ic.on.a-shine{animation:tpShine 2.2s ease-in-out var(--d,0s) infinite}
 .tp-ic.on.pop{animation:tpPop .4s ease-out}
 @keyframes tpPulse{0%,100%{transform:scale(1);filter:drop-shadow(0 0 3px var(--c))}50%{transform:scale(1.12);filter:drop-shadow(0 0 10px var(--c))}}
 @keyframes tpSpin{to{transform:rotate(360deg)}}
 @keyframes tpFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
 @keyframes tpSway{0%,100%{transform:rotate(-14deg)}50%{transform:rotate(14deg)}}
 @keyframes tpFlick{0%,100%{transform:scale(1,1);filter:drop-shadow(0 0 4px var(--c))}25%{transform:scale(.94,1.1);filter:drop-shadow(0 0 10px var(--c))}50%{transform:scale(1.05,.95)}75%{transform:scale(.96,1.07);filter:drop-shadow(0 0 8px var(--c))}}
 @keyframes tpRainbow{from{filter:hue-rotate(0deg) drop-shadow(0 0 5px var(--c))}to{filter:hue-rotate(360deg) drop-shadow(0 0 5px var(--c))}}
 @keyframes tpShine{0%,100%{filter:brightness(1) drop-shadow(0 0 3px var(--c))}50%{filter:brightness(1.7) drop-shadow(0 0 12px var(--c))}}
 @keyframes tpPop{0%{transform:scale(.4) rotate(-40deg)}60%{transform:scale(1.3) rotate(10deg)}100%{transform:scale(1) rotate(0)}}
 .tp-gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));gap:8px;margin:8px 0}
 .tp-gal button{display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px 4px;font-size:12px;line-height:1.2;background:#172830!important}
 .tp-gal button.sel{outline:2px solid #49ddaf}
 @media (prefers-reduced-motion:reduce){.tp-ic.on{animation:none!important}}
 `;
 document.head.append(style);
 const panel=el('section');panel.id='tf-pontos';panel.hidden=true;document.body.append(panel);
 let curId=null,timer=null;
 const close=()=>{panel.hidden=true;panel.replaceChildren();clearInterval(timer);timer=null;};
 const btn=(t,fn,cls)=>{const b=el('button',t,cls);b.type='button';b.onclick=fn;return b;};
 const num=(v,d)=>{const n=parseFloat(String(v).replace(',','.'));return Number.isFinite(n)?n:d;};

 function open(id){
  const list=trainers();
  panel.replaceChildren();panel.hidden=false;
  if(!list.length){const h=el('div',null,'tp-h');h.append(el('strong','⭐ Pontuação'),btn('✕',close));panel.append(h);const b=el('div',null,'tp-b');b.append(el('p','Crie um treinador na galeria primeiro.'));panel.append(b);return;}
  if(!id||!list.find(p=>p.id===id))id=(list.find(p=>p.id===curId)||list[0]).id;
  curId=id;autoReset();
  const o=T(id),s=o.stars,P=o.pts;
  const head=el('div',null,'tp-h');head.append(btn('←',close),el('strong','⭐ Pontuação'));panel.append(head);
  const body=el('div',null,'tp-b');panel.append(body);
  const redraw=()=>{const y=body.scrollTop;open(id);const nb=$('.tp-b',panel);if(nb)nb.scrollTop=y;};

  /* escolher treinador + ir ao menos usado */
  const top=el('div',null,'tp-r');const sel=el('select');list.forEach(p=>{const op=el('option',(p.emoji||'👤')+' '+(p.nome||'Treinador'));op.value=p.id;if(p.id===id)op.selected=true;sel.append(op);});sel.onchange=()=>open(sel.value);top.append(sel);body.append(top);
  const lu=leastUsed();
  const go=btn('🎯 Ir ao treinador menos usado',()=>{const u=leastUsed();if(!u)return;close();try{openEditor(u.id);}catch(e){say('Não consegui abrir o treinador: '+e.message);}},'pri');const refreshGo=()=>{const u=leastUsed();go.textContent='🎯 Ir ao treinador menos usado'+(u?' ('+(u.nome||'Treinador')+')':'');};refreshGo();go.style.width='100%';body.append(go);

  /* ===== ESTRELAS ===== */
  const cs=el('div',null,'tp-c');cs.append(el('h3','Série de uso'));
  const lbl=el('input');lbl.value=s.label;lbl.placeholder='Nome da série';lbl.onchange=()=>{s.label=lbl.value.slice(0,40);save();};cs.append(lbl);
  const stars=el('div',null,'tp-stars');
  const drawStars=()=>{refreshGo();try{nu.value=s.used;}catch(_){}stars.replaceChildren();const n=Math.max(0,Math.min(200,Math.round(s.total)));for(let i=0;i<n;i++){const lit=i<s.used,e=icEl(s.icon,lit?true:false,s.on,s.off,s.size,s.anim,s.halfMode,i);e.onclick=()=>{s.used=(s.used===i+1)?i:i+1;save();drawStars();info.textContent=s.used+' de '+n+' usados';const t=stars.children[Math.max(0,s.used-1)];if(t&&s.used>0){t.classList.add('pop');t.addEventListener('animationend',()=>t.classList.remove('pop'),{once:true});}};stars.append(e);}};
  const info=el('div',s.used+' de '+Math.round(s.total)+' usados');info.style.cssText='font-weight:700;margin:4px 0';
  cs.append(stars,info);
  const row1=el('div',null,'tp-r');
  const mk=(t,fn)=>btn(t,()=>{fn();s.used=Math.max(0,Math.min(Math.round(s.total),s.used));save();drawStars();info.textContent=s.used+' de '+Math.round(s.total)+' usados';});
  row1.append(mk('➖ 1',()=>s.used--),mk('➕ Usei 1',()=>s.used++),btn('🔄 Resetar agora',()=>{if(!confirm('Zerar as estrelas usadas deste treinador?'))return;s.used=0;s.lastReset=Date.now();save();drawStars();info.textContent='0 de '+Math.round(s.total)+' usados';say('Estrelas zeradas.');}));cs.append(row1);
  const row2=el('div',null,'tp-r');
  const nt=el('input');nt.type='number';nt.min=1;nt.max=200;nt.value=s.total;nt.onchange=()=>{s.total=Math.max(1,Math.min(200,Math.round(num(nt.value,10))));nt.value=s.total;s.used=Math.min(s.used,s.total);save();drawStars();info.textContent=s.used+' de '+s.total+' usados';};
  const nu=el('input');nu.type='number';nu.min=0;nu.value=s.used;nu.onchange=()=>{s.used=Math.max(0,Math.min(Math.round(s.total),Math.round(num(nu.value,0))));nu.value=s.used;save();drawStars();info.textContent=s.used+' de '+Math.round(s.total)+' usados';};
  const l1=el('label','Total ');l1.append(nt);const l2=el('label','Usados ');l2.append(nu);row2.append(l1,l2);cs.append(row2);
  const row3=el('div',null,'tp-r');
  const own=el('input');own.placeholder='ou seu emoji';own.style.width='110px';own.onchange=()=>{const v=[...own.value.trim()][0];if(v){s.icon=v;save();redraw();}};if(!ICONS[s.icon]){own.value=s.icon;}
  const cOn=el('input');cOn.type='color';cOn.value=s.on;cOn.oninput=()=>{s.on=cOn.value;save();drawStars();};
  const cOff=el('input');cOff.type='color';cOff.value=s.off;cOff.oninput=()=>{s.off=cOff.value;save();drawStars();};
  const sz=el('input');sz.type='range';sz.min=14;sz.max=60;sz.value=s.size;sz.oninput=()=>{s.size=+sz.value;save();drawStars();};
  const la=el('label','Emoji próprio ');la.append(own);const lb=el('label','Cor usado ');lb.append(cOn);const lc=el('label','Cor vazio ');lc.append(cOff);const ld=el('label','Tamanho ');ld.append(sz);row3.append(la,lb,lc,ld);cs.append(row3);
  const PRE=[{n:'Eclipse dourado',i:'half',on:'#ffc21a',off:'#3a3f47',a:'float'},{n:'Eclipse giratório',i:'eclipse',on:'#e6e9ff',off:'#2e3340',a:'spin'},{n:'Lua prateada',i:'crescent',on:'#cfd8e3',off:'#38404a',a:'float'},{n:'Lua cheia com sombra',i:'moon',on:'#f3f0c8',off:'#3a3d44',a:'pulse',h:1},{n:'Coroa real',i:'crown',on:'#ffd24d',off:'#4a4430',a:'shine'},{n:'Coroa meia sombra',i:'crown',on:'#ffd24d',off:'#3a3a40',a:'pulse',h:1},{n:'Espadas de fogo',i:'swords',on:'#ff6a2a',off:'#473630',a:'sway'},{n:'Espada de gelo',i:'sword',on:'#7fd8ff',off:'#34444d',a:'shine'},{n:'Leque rosa',i:'fan',on:'#ff5fa2',off:'#46303c',a:'sway'},{n:'Escudo azul',i:'shield',on:'#4aa3ff',off:'#2f3e50',a:'pulse'},{n:'Raio elétrico',i:'bolt',on:'#ffe94a',off:'#4a4830',a:'flicker'},{n:'Chama viva',i:'flame',on:'#ff7b1a',off:'#4a3a30',a:'flicker'},{n:'Diamante arco-íris',i:'diamond',on:'#6ee7ff',off:'#33454d',a:'rainbow'},{n:'Sol giratório',i:'sun',on:'#ffb020',off:'#4a4030',a:'spin'},{n:'Coração batendo',i:'heart',on:'#ff4d6d',off:'#4a3038',a:'pulse'},{n:'Estrela clássica',i:'star',on:'#ffc21a',off:'#4a5560',a:'pulse'}];
  cs.append(el('h3','🎨 Estilos prontos (toque para usar)'));
  const gal=el('div',null,'tp-gal');PRE.forEach(p=>{const b=btn('',()=>{Object.assign(s,{icon:p.i,on:p.on,off:p.off,anim:p.a,halfMode:!!p.h});save();redraw();});b.append(icEl(p.i,true,p.on,p.off,34,p.a,!!p.h,0),el('span',p.n));if(s.icon===p.i&&s.on===p.on&&(s.anim||'pulse')===p.a&&!!s.halfMode===!!p.h)b.classList.add('sel');gal.append(b);});cs.append(gal);
  cs.append(el('h3','Ícone'));
  const grid=el('div',null,'tp-gal');Object.keys(ICONS).forEach(k=>{const b=btn('',()=>{s.icon=k;save();redraw();});b.append(icEl(k,true,s.on,s.off,34,s.anim,s.halfMode,0),el('span',ICONS[k]));if(k===s.icon)b.classList.add('sel');grid.append(b);});cs.append(grid);
  const row5=el('div',null,'tp-r');const an=el('select');Object.keys(ANIMS).forEach(k=>{const op=el('option',ANIMS[k]);op.value=k;an.append(op);});an.value=s.anim||'pulse';an.onchange=()=>{s.anim=an.value;save();redraw();};
  const hf=el('input');hf.type='checkbox';hf.checked=!!s.halfMode;hf.onchange=()=>{s.halfMode=hf.checked;save();redraw();};
  const la2=el('label','Animação ');la2.append(an);const lh=el('label','🌗 Metade luz / metade sombra ');lh.append(hf);row5.append(la2,lh);cs.append(row5);

  const row4=el('div',null,'tp-r');const rh=el('select');const o0=el('option','Reset manual (só pelo botão)');o0.value=-1;rh.append(o0);for(let h=0;h<24;h++){const op=el('option','Resetar todo dia às '+String(h).padStart(2,'0')+':00');op.value=h;rh.append(op);}rh.value=s.resetHour;
  rh.onchange=()=>{s.resetHour=+rh.value;s.lastReset=Date.now();save();say(s.resetHour<0?'Reset manual.':'Reset automático às '+String(s.resetHour).padStart(2,'0')+':00 (hora do celular).');};
  row4.append(rh);cs.append(row4);
  const nota=el('small','O reset automático é conferido quando você abre o app (e a cada minuto com ele aberto). Se o horário passou com o app fechado, as estrelas zeram ao abrir.');nota.style.color='#a6c5cf';cs.append(nota);
  drawStars();body.append(cs);

  /* ===== PONTOS ===== */
  const cp=el('div',null,'tp-c');cp.append(el('h3','Pontos'));
  const tot=el('div',null,'tp-big');const tag=el('div');
  const drawTotal=()=>{const t=total(o);tot.textContent=String(Math.round(t*100)/100).replace('.',',');const h=P.hist[P.hist.length-1];tag.replaceChildren();if(h){const t2=el('span',(h.icon?h.icon+' ':'')+(h.label?h.label+' ':'')+fmt(h.delta),'tp-tag');t2.style.background=h.color||(h.delta>=0?P.plus:P.minus);tag.append(el('small','Último: '),t2);}else tag.append(el('small','Nenhum lançamento ainda.'));};
  cp.append(tot,tag);
  const rb=el('div',null,'tp-r');const base=el('input');base.type='number';base.value=P.base;base.onchange=()=>{P.base=num(base.value,100);save();drawTotal();};const lbase=el('label','Base ');lbase.append(base);
  const cplus=el('input');cplus.type='color';cplus.value=P.plus;cplus.oninput=()=>{P.plus=cplus.value;save();drawTotal();drawHist();};const cminus=el('input');cminus.type='color';cminus.value=P.minus;cminus.oninput=()=>{P.minus=cminus.value;save();drawTotal();drawHist();};
  const lp=el('label','Cor + ');lp.append(cplus);const lm=el('label','Cor − ');lm.append(cminus);rb.append(lbase,lp,lm);cp.append(rb);

  /* lançamento rápido: +20 / -20 */
  const q=el('div',null,'tp-r');const qv=el('input');qv.placeholder='+20 ou -20';qv.inputMode='text';qv.style.width='110px';const ql=el('input');ql.placeholder='O que foi (ex.: lógica)';ql.style.flex='1';ql.style.minWidth='110px';
  const qe=el('input');qe.placeholder='😀';qe.style.width='56px';
  let img='';const qf=el('input');qf.type='file';qf.accept='image/*';qf.hidden=true;const qi=btn('🖼',()=>qf.click());
  qf.onchange=()=>{const f=qf.files[0];if(!f)return;const im=new Image(),u=URL.createObjectURL(f);im.onload=()=>{const c=document.createElement('canvas'),k=Math.min(1,96/Math.max(im.width,im.height));c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));c.getContext('2d').drawImage(im,0,0,c.width,c.height);img=c.toDataURL('image/jpeg',.8);URL.revokeObjectURL(u);qi.textContent='✅';};im.onerror=()=>{URL.revokeObjectURL(u);say('Não consegui ler essa imagem.');};im.src=u;};
  const qc=el('input');qc.type='color';qc.value='#ffffff';qc.title='Cor da etiqueta (deixe branco para usar verde/vermelho)';let qcSet=false;qc.oninput=()=>{qcSet=true;};
  const add=(label,icon,image,delta,color)=>{P.hist.push({id:uid(),label,icon,img:image,delta,color,time:Date.now()});if(P.hist.length>500)P.hist.splice(0,P.hist.length-500);save();drawTotal();drawHist();};
  const go2=btn('➕ Lançar',()=>{const m=/^\s*([+\-−])?\s*(\d+(?:[.,]\d+)?)\s*$/.exec(qv.value);if(!m)return say('Digite um valor como +20 ou -20.');const d=(m[1]==='-'||m[1]==='−'?-1:1)*num(m[2],0);const col=qcSet?qc.value:'';add(ql.value.trim(),qe.value.trim(),img,d,col);
   if(ql.value.trim()&&!P.items.find(i=>i.label===ql.value.trim()&&i.delta===d)){P.items.push({id:uid(),label:ql.value.trim(),icon:qe.value.trim(),img,delta:d,color:col});save();drawItems();}
   qv.value='';ql.value='';qe.value='';img='';qi.textContent='🖼';qcSet=false;},'pri');
  q.append(qv,ql,qe,qi,qc,go2,qf);cp.append(q);
  const itemsBox=el('div',null,'tp-r');const drawItems=()=>{itemsBox.replaceChildren();P.items.forEach(it=>{const w=el('span',null,'tp-it');const b=btn((it.img?'':(it.icon?it.icon+' ':''))+(it.label||'item')+' '+fmt(it.delta),()=>add(it.label,it.icon,it.img,it.delta,it.color));if(it.img){const im=el('img');im.src=it.img;im.style.cssText='width:22px;height:22px;object-fit:cover;border-radius:5px;vertical-align:middle;margin-right:5px';b.prepend(im);}b.style.borderColor=it.color||(it.delta>=0?P.plus:P.minus);const x=btn('✕',()=>{if(!confirm('Apagar o atalho "'+(it.label||'item')+'"? (os lançamentos já feitos continuam)'))return;P.items=P.items.filter(i=>i.id!==it.id);save();drawItems();});x.style.minHeight='34px';x.style.padding='4px 8px';w.append(b,x);itemsBox.append(w);});};
  cp.append(el('small','Atalhos (toque para lançar de novo):'));drawItems();cp.append(itemsBox);
  const hist=el('div');const drawHist=()=>{hist.replaceChildren();P.hist.slice(-15).reverse().forEach(h=>{const r=el('div',null,'tp-hist');const d=el('span',fmt(h.delta),'d');d.style.color=h.color||(h.delta>=0?P.plus:P.minus);r.append(d);if(h.img){const im=el('img');im.src=h.img;r.append(im);}r.append(el('span',(h.icon?h.icon+' ':'')+(h.label||'—')));const when=el('small',new Date(h.time).toLocaleDateString('pt-BR')+' '+new Date(h.time).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}));when.style.marginLeft='auto';r.append(when);const x=btn('↩',()=>{P.hist=P.hist.filter(z=>z.id!==h.id);save();drawTotal();drawHist();});x.style.minHeight='32px';x.style.padding='3px 8px';x.title='Desfazer este lançamento';r.append(x);hist.append(r);});};
  drawTotal();drawHist();cp.append(hist);
  const zero=btn('🗑 Zerar pontos (volta à base)',()=>{if(!confirm('Apagar todos os lançamentos deste treinador? A base é mantida.'))return;P.hist=[];save();drawTotal();drawHist();});zero.style.marginTop='8px';cp.append(zero);
  body.append(cp);

  clearInterval(timer);timer=setInterval(()=>{if(!panel.hidden&&autoReset()){const y=body.scrollTop;open(id);const nb=$('.tp-b',panel);if(nb)nb.scrollTop=y;}},60000);
 }

 /* botão de entrada, ao lado do botão de ligações */
 const launch=btn('⭐ Pontuação',()=>open(),'hbtn');launch.id='tc-pontos-btn';
 const gal=$('#tc-gallery'),bar=$('#busca');
 if(gal)gal.after(launch);else if(bar&&bar.parentElement)bar.parentElement.append(launch);else document.body.append(launch);
 window.tfPontosOpen=open;
 window.tfPontosAutoReset=autoReset;
 autoReset();
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden){e.preventDefault();close();}});
})();
