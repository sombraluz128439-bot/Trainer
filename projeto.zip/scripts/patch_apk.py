#!/usr/bin/env python3
"""Patch the HTML/JS/CSS assets of the recovered Treinadores Falantes APK.

The native Android classes and manifest are preserved from the supplied APK.
The APK is intentionally emitted unsigned; CI signs and zipaligns it with Android SDK tools.
"""
from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BASE = ROOT / "reference" / "base-app-debug.apk"
DEFAULT_OUT = ROOT / "build" / "unsigned.apk"
ASSETS = {
    "assets/index.html": ROOT / "www" / "index.html",
    "assets/calls.js": ROOT / "www" / "calls.js",
    "assets/calls.css": ROOT / "www" / "calls.css",
    "assets/pontos.js": ROOT / "www" / "pontos.js",
}
FONTS_DIR = ROOT / "www" / "fonts"


def font_assets() -> dict:
    """Todas as fontes (fonts.css, manifest.json e files/*) vão para assets/fonts/ dentro do APK."""
    out = {}
    if FONTS_DIR.is_dir():
        for f in sorted(FONTS_DIR.rglob("*")):
            if f.is_file():
                out["assets/fonts/" + f.relative_to(FONTS_DIR).as_posix()] = f
    return out



def is_signature_file(name: str) -> bool:
    upper = name.upper()
    return upper.startswith("META-INF/") and upper.endswith((".SF", ".RSA", ".DSA", ".EC"))


def patch(base: Path, output: Path) -> None:
    if not base.is_file():
        raise FileNotFoundError(f"APK de referência não encontrado: {base}")
    for archive_name, source in ASSETS.items():
        if not source.is_file():
            raise FileNotFoundError(f"Arquivo de interface ausente: {source}")

    fonts = font_assets()
    sources = {**ASSETS, **fonts}
    output.parent.mkdir(parents=True, exist_ok=True)
    replacements = {name: path.read_bytes() for name, path in sources.items()}
    seen: set[str] = set()

    with zipfile.ZipFile(base, "r") as zin:
        bad = zin.testzip()
        if bad:
            raise zipfile.BadZipFile(f"Entrada corrompida no APK de referência: {bad}")
        names = set(zin.namelist())
        # index.html, calls.js e calls.css TÊM de existir no APK base; os demais (pontos.js, fontes) podem ser novos.
        missing = {"assets/index.html", "assets/calls.js", "assets/calls.css"} - names
        if missing:
            raise RuntimeError("O APK base não contém os assets esperados: " + ", ".join(sorted(missing)))

        with zipfile.ZipFile(output, "w") as zout:
            zout.comment = zin.comment
            for info in zin.infolist():
                name = info.filename
                if name in replacements:
                    zout.writestr(info, replacements[name])
                    seen.add(name)
                    continue
                # Assinatura v2/v3 fica fora das entradas ZIP e não é copiada; remove só metadados v1.
                if is_signature_file(name):
                    continue
                zout.writestr(info, zin.read(name))
            for name in sorted(set(replacements) - seen):
                zout.writestr(zipfile.ZipInfo(name, date_time=(2024, 1, 1, 0, 0, 0)), replacements[name], zipfile.ZIP_DEFLATED)
                seen.add(name)

    with zipfile.ZipFile(output, "r") as check:
        bad = check.testzip()
        if bad:
            raise zipfile.BadZipFile(f"APK de saída corrompido: {bad}")
        for name, expected in replacements.items():
            if check.read(name) != expected:
                raise RuntimeError(f"Falha ao validar asset no APK: {name}")

    nfont = len(fonts)
    print(f"APK preparado sem assinatura: {output}")
    print(f"Assets interface: {', '.join(sorted(ASSETS))}")
    print(f"Arquivos de fonte embutidos: {nfont}")
    if nfont <= 3:
        print("AVISO: só a fonte Poppins base foi embutida (o passo de baixar fontes não rodou ou falhou).", file=sys.stderr)
    print("Classes Android originais, manifesto, ícones e recursos foram preservados.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=DEFAULT_BASE, help="APK original de referência")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT, help="APK sem assinatura a gerar")
    args = parser.parse_args()
    try:
        patch(args.base, args.output)
    except Exception as exc:
        print(f"ERRO: {exc}", file=sys.stderr)
        raise SystemExit(1)
