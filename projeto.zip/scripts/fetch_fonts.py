#!/usr/bin/env python3
"""Baixa as fontes do Google Fonts NA COMPILAÇÃO e as coloca em www/fonts/ para ir dentro do APK.

O app é 100% offline (o WebView bloqueia a internet), então as fontes não podem ser baixadas no
celular. Este script roda no GitHub Actions (que tem internet), gera:
  www/fonts/files/*.woff2   arquivos das fontes (somente subconjuntos latin e latin-ext)
  www/fonts/fonts.css       @font-face apontando para files/...
  www/fonts/manifest.json   lista das famílias COMPLETAS (todos os pesos pedidos)
É "melhor esforço": se uma fonte falhar, as outras continuam e o build não quebra.
"""
from __future__ import annotations
import argparse, hashlib, json, os, re, sys, time, urllib.parse, urllib.request
from pathlib import Path

UA = ("Mozilla/5.0 (Linux; Android 13; Moto G52) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/120.0.0.0 Mobile Safari/537.36")
KEEP_SUBSETS = {"latin", "latin-ext"}


def specs_from_index(index: Path) -> list[str]:
    html = index.read_text(encoding="utf-8")
    m = re.search(r"const FAM=\[(.*?)\];", html, re.S)
    if not m:
        raise SystemExit("Não achei a lista FAM em index.html")
    specs = re.findall(r"'([^']+)'", m.group(1))
    # fontes cursivas (CURS) que o index.html acrescenta a FAM
    mc = re.search(r"const CURS=\[(.*?)\];", html, re.S)
    if mc:
        for n in re.findall(r"'([^']+)'", mc.group(1)):
            specs.append(n.replace(" ", "+") + (":wght@400;700" if n in ("Dancing Script", "Tangerine") else ""))
    # fontes pedidas por <link> fixo no index.html (cenas de efeitos)
    for link in re.findall(r"css2\?family=([A-Za-z][^'\"&]*(?:&family=[^'\"&]+)*)&display=swap", html):
        specs.extend(s for s in link.split("&family=") if s)
    seen, out = set(), []
    for s in specs:
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


def want_weights(spec: str) -> set[str]:
    m = re.search(r"wght@([0-9;.]+)", spec)
    return set(m.group(1).split(";")) if m else {"400"}


def family_of(spec: str) -> str:
    return urllib.parse.unquote(spec.split(":")[0].replace("+", " "))


def get(url: str, tries: int = 3, binary: bool = False):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=40) as r:
                data = r.read()
            return data if binary else data.decode("utf-8")
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(1.5 * (i + 1))
    raise RuntimeError(f"{url}: {last}")


BLOCK = re.compile(r"/\*\s*([a-z0-9-]+)\s*\*/\s*@font-face\s*\{(.*?)\}", re.S | re.I)


def parse_blocks(css: str):
    for sub, body in BLOCK.findall(css):
        def prop(name):
            m = re.search(name + r"\s*:\s*([^;]+);", body, re.I)
            return m.group(1).strip() if m else None
        url = re.search(r"url\(\s*['\"]?([^'\")]+)['\"]?\s*\)", body or "")
        if not url:
            continue
        fam = (prop("font-family") or "").strip("'\" ")
        yield {
            "subset": sub.lower(), "family": fam, "style": prop("font-style") or "normal",
            "weight": (prop("font-weight") or "400").split()[0], "url": url.group(1),
            "range": prop("unicode-range"),
        }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", type=Path, default=Path("www/index.html"))
    ap.add_argument("--out", type=Path, default=Path("www/fonts"))
    ap.add_argument("--css-base", default="https://fonts.googleapis.com/css2")
    ap.add_argument("--strict", action="store_true", help="falha se alguma fonte faltar")
    a = ap.parse_args()

    specs = specs_from_index(a.index)
    files = a.out / "files"
    files.mkdir(parents=True, exist_ok=True)
    css_out, downloaded = [], {}
    fam_ok: dict[str, bool] = {}
    problems = []
    for spec in specs:
        fam = family_of(spec)
        try:
            css = get(f"{a.css_base}?family={spec}&display=swap")
            blocks = [b for b in parse_blocks(css) if b["subset"] in KEEP_SUBSETS]
            if not blocks:
                raise RuntimeError("CSS sem blocos latin")
            got_latin = {b["weight"] for b in blocks if b["subset"] == "latin"}
            for b in blocks:
                u = b["url"]
                if u not in downloaded:
                    ext = ".woff2" if ".woff2" in u or "woff2" in u else ".woff"
                    name = hashlib.sha1(u.encode()).hexdigest()[:16] + ext
                    data = get(u, binary=True)
                    if len(data) < 500:
                        raise RuntimeError(f"arquivo suspeito ({len(data)} bytes)")
                    (files / name).write_bytes(data)
                    downloaded[u] = name
                rule = (f"@font-face{{font-family:'{b['family'] or fam}';font-style:{b['style']};"
                        f"font-weight:{b['weight']};font-display:swap;"
                        f"src:url(files/{downloaded[u]}) format('{'woff2' if downloaded[u].endswith('2') else 'woff'}');")
                if b["range"]:
                    rule += f"unicode-range:{b['range']};"
                css_out.append(rule + "}")
            ok = want_weights(spec) <= got_latin
            fam_ok[fam] = fam_ok.get(fam, True) and ok
            if not ok:
                problems.append(f"{fam}: faltam pesos {sorted(want_weights(spec) - got_latin)}")
        except Exception as e:  # noqa: BLE001
            fam_ok[fam] = False
            problems.append(f"{fam}: {e}")
    if not downloaded:
        print("Nenhuma fonte baixada (sem internet?). Mantendo o que já está em www/fonts/.")
        for p in problems[:5]:
            print("  aviso:", p)
        return 1 if a.strict else 0
    css_text = "/* gerado por scripts/fetch_fonts.py */\n" + "\n".join(dict.fromkeys(css_out)) + "\n"
    (a.out / "fonts.css").write_text(css_text, encoding="utf-8")
    families = sorted(f for f, ok in fam_ok.items() if ok)
    (a.out / "manifest.json").write_text(
        json.dumps({"families": families, "total": len(fam_ok), "files": len(downloaded)}, ensure_ascii=False, indent=1),
        encoding="utf-8")
    print(f"Fontes: {len(families)}/{len(fam_ok)} famílias completas, {len(downloaded)} arquivos.")
    for p in problems:
        print("  aviso:", p)
    return 1 if (a.strict and problems) else 0


if __name__ == "__main__":
    sys.exit(main())
