# Treinadores Falantes — pacote recuperado e corrigido

Este pacote atualiza a interface web do APK fornecido e preserva os arquivos Android nativos, o manifesto, os recursos e o serviço nativo do balão flutuante.

## O que foi ajustado

- Tela de chamada simulada offline com imagem/vídeo preenchendo a tela por padrão (modo **Tela cheia**). Também há opções para mostrar a mídia inteira ou esticá-la; o usuário pode ampliar e deslocar a mídia.
- MP4 na tela de chamada começa silencioso e ganhou controle para ativar/desativar o áudio original.
- Cada personagem mantém sua própria escolha de voz TTS offline, velocidade e tom.
- Importação de MP3, OGG, WAV, M4A e MP4 como gravações originais. É possível cadastrar uma frase-gatilho; ao enviar exatamente essa frase, o app reproduz a gravação importada.
- Texto que não corresponda a uma frase-gatilho continua sendo lido pela voz TTS offline instalada e escolhida para aquele personagem.
- Conversa local com alternância de autor (Eu/personagem), emojis, notas, avaliações e anexos de imagem, vídeo e áudio.
- Download de fontes com até três tentativas de rede por arquivo, tempo limite ampliado, verificação de CSS/WOFF2, cache em IndexedDB e botão manual. A interface agora informa quais fontes falharam e o motivo retornado pelo aparelho/servidor.
- A seta **←** para sair fica sempre visível; o campo **Digite o que o personagem vai falar** permanece fixo na parte inferior e mostra uma prévia do texto enviado. Os outros controles recolhem após inatividade e reaparecem ao tocar na tela.

## Limites importantes

1. **MP4 não é um modelo de clonagem de voz.** O MP4 pode ser tocado como gravação original e associado a uma frase exata. Para sintetizar qualquer texto com uma voz idêntica é necessário um modelo TTS/voice-cloning treinado e compatível. Esse runtime de clonagem não existe no APK de referência e não foi possível adicioná-lo com segurança sem o código-fonte Android e o modelo apropriado.
2. As vozes TTS disponíveis são as que o motor Android instalado disponibiliza e que funcionam offline. O app não baixa automaticamente vozes TTS novas; a instalação é feita nas configurações de Texto para fala do Android.
3. A ligação e o chat são uma **simulação local**, não telefonia real, WhatsApp, serviço de IA ou mensagens enviadas a outra pessoa.
4. O APK original foi a única base Android disponível. Os componentes nativos foram preservados; as alterações feitas aqui foram nos assets HTML/CSS/JavaScript. Não havia código Gradle nativo completo no arquivo ZIP antigo.
5. A lista de fontes vem do Google Fonts. Para baixar fontes, o aparelho precisa estar online e conseguir acessar `fonts.googleapis.com` e `fonts.gstatic.com`. Depois que os arquivos são efetivamente salvos, passam a funcionar offline. As tentativas e mensagens de erro foram melhoradas, mas bloqueios de rede, DNS, certificados ou falta de espaço ainda podem impedir um download; a confirmação final precisa ser feita no próprio Moto G52.

## Gerar APK no GitHub Actions

O workflow está em `.github/workflows/build.yml` (cópia também na raiz como `build.yml`). O Actions baixa as ferramentas Android, substitui os três assets no APK de referência, faz `zipalign`, assina com `apksigner`, verifica a assinatura e publica o artefato `treinadores-offline-apk`.

Por padrão, o workflow cria uma chave de depuração temporária. Para gerar atualizações instaláveis por cima da mesma versão, configure os segredos `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` e `KEY_PASSWORD` com uma chave permanente sua. Sem isso, APKs de execuções diferentes terão assinaturas diferentes e pode ser necessário desinstalar a versão anterior antes de instalar a nova.

## Estrutura

- `reference/base-app-debug.apk`: APK fornecido usado como base.
- `www/index.html`, `www/calls.js`, `www/calls.css`: interface atualizada.
- `scripts/patch_apk.py`: reconstrói o APK sem assinatura usando os arquivos atualizados.
- `build.yml`: cópia de conveniência; o GitHub Actions lê a cópia dentro de `.github/workflows/`.

## Testes feitos neste pacote

- `node --check` no módulo `calls.js`.
- `node --check` nos 23 blocos JavaScript inline do `index.html`.
- Validação ZIP e conferência dos três assets após a reconstrução do APK.
- Verificação da assinatura v1 do APK gerado com a chave de depuração do projeto.

**Não foi possível executar a instalação em um aparelho Android neste ambiente.** Faça backup dos seus dados antes de substituir o app.
