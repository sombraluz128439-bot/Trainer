#!/usr/bin/env python3
"""Patch the HTML/JS/CSS assets of the recovered Treinadores Falantes APK.

The native Android classes and manifest are preserved from the supplied APK.
The APK is intentionally emitted unsigned; CI signs and zipaligns it with Android SDK tools.
"""
from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BASE = ROOT / "reference" / "base-app-debug.apk"
DEFAULT_OUT = ROOT / "build" / "unsigned.apk"
ASSETS = {
    "assets/index.html": ROOT / "www" / "index.html",
    "assets/calls.js": ROOT / "www" / "calls.js",
    "assets/calls.css": ROOT / "www" / "calls.css",
}


def is_signature_file(name: str) -> bool:
    upper = name.upper()
    return upper.startswith("META-INF/") and upper.endswith((".SF", ".RSA", ".DSA", ".EC"))


def patch(base: Path, output: Path) -> None:
    if not base.is_file():
        raise FileNotFoundError(f"APK de referência não encontrado: {base}")
    for archive_name, source in ASSETS.items():
        if not source.is_file():
            raise FileNotFoundError(f"Arquivo de interface ausente: {source}")

    output.parent.mkdir(parents=True, exist_ok=True)
    replacements = {name: path.read_bytes() for name, path in ASSETS.items()}
    seen: set[str] = set()

    with zipfile.ZipFile(base, "r") as zin:
        bad = zin.testzip()
        if bad:
            raise zipfile.BadZipFile(f"Entrada corrompida no APK de referência: {bad}")
        names = set(zin.namelist())
        missing = set(replacements) - names
        if missing:
            raise RuntimeError("O APK não contém os assets esperados: " + ", ".join(sorted(missing)))

        with zipfile.ZipFile(output, "w") as zout:
            zout.comment = zin.comment
            for info in zin.infolist():
                name = info.filename
                if name in replacements:
                    zout.writestr(info, replacements[name])
                    seen.add(name)
                    continue
                # The APK v2/v3 signing block is outside ZIP entries and is not copied.
                # Remove only v1 signing metadata if the input ever contains it.
                if is_signature_file(name):
                    continue
                zout.writestr(info, zin.read(name))

    if seen != set(replacements):
        raise RuntimeError("Nem todos os assets foram substituídos.")

    with zipfile.ZipFile(output, "r") as check:
        bad = check.testzip()
        if bad:
            raise zipfile.BadZipFile(f"APK de saída corrompido: {bad}")
        for name, expected in replacements.items():
            if check.read(name) != expected:
                raise RuntimeError(f"Falha ao validar asset no APK: {name}")

    print(f"APK preparado sem assinatura: {output}")
    print("Assets substituídos: " + ", ".join(sorted(seen)))
    print("Classes Android originais, manifesto, ícones e recursos foram preservados.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=DEFAULT_BASE, help="APK original de referência")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT, help="APK sem assinatura a gerar")
    args = parser.parse_args()
    try:
        patch(args.base, args.output)
    except Exception as exc:
        print(f"ERRO: {exc}", file=sys.stderr)
        raise SystemExit(1)
