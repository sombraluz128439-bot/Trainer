package com.treinadores.flutuantes;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;

/** Seletor do Android para o WebView flutuante, sem abrir/recarregar o editor. */
public class FilePickerActivity extends Activity {
    private static ValueCallback<Uri[]> pending;
    private boolean completed;
    public static synchronized boolean open(Context context,ValueCallback<Uri[]> cb,Intent picker) {
        if(pending!=null) {cb.onReceiveValue(null);return true;}
        pending=cb;
        try {
            Intent launch=new Intent(context,FilePickerActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            launch.putExtra("picker",picker);context.startActivity(launch);return true;
        }catch(Exception e){pending=null;return false;}
    }
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if(state==null) {
            try {
                Intent picker=getIntent().getParcelableExtra("picker");
                if(picker==null)throw new IllegalArgumentException();
                startActivityForResult(picker,41);
            }catch(Exception e){deliver(null);finish();}
        }
    }
    private void deliver(Uri[] uris) {
        completed=true;
        ValueCallback<Uri[]> cb;
        synchronized(FilePickerActivity.class){cb=pending;pending=null;}
        if(cb!=null)cb.onReceiveValue(uris);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==41) {
            Uri[] out=null;
            if(result==RESULT_OK && data!=null && data.getClipData()!=null) {
                int n=data.getClipData().getItemCount();out=new Uri[n];
                for(int i=0;i<n;i++)out[i]=data.getClipData().getItemAt(i).getUri();
            }else out=WebChromeClient.FileChooserParams.parseResult(result,data);
            deliver(out);finish();
        }
    }
    @Override protected void onDestroy() {
        if(!completed && !isChangingConfigurations())deliver(null);
        super.onDestroy();
    }
}
