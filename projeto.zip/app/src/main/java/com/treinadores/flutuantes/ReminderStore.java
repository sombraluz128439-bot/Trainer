package com.treinadores.flutuantes;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Build;
import android.provider.Settings;
import android.widget.RemoteViews;
import org.json.*;
import java.time.*;

/** Lembretes nativos: independem da bolha, do WebView e dos timers JavaScript. */
public final class ReminderStore {
    private ReminderStore() {}
    static android.content.SharedPreferences prefs(Context c) { return c.getSharedPreferences("lembretes_v1", 0); }
    public static synchronized JSONArray all(Context c) {
        try { return new JSONArray(prefs(c).getString("items", "[]")); } catch(Exception e) { return new JSONArray(); }
    }
    static void persist(Context c, JSONArray a) {
        if(!prefs(c).edit().putString("items", a.toString()).commit()) throw new IllegalStateException("Não foi possível salvar no aparelho.");
    }
    public static boolean exact(Context c) { return Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager.class).canScheduleExactAlarms(); }
    public static boolean allowed(Context c) { return c.getSystemService(NotificationManager.class).areNotificationsEnabled(); }
    static String text(JSONObject o, String k, String def, int max) { String s=o.optString(k,def); return s; }
    static int parseHex(String s) {if(!s.matches("#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?"))throw new IllegalArgumentException("Cor inválida");return (int)Long.parseLong(s.substring(1),16)|0xff000000;}
    static int color(JSONObject o,String k,String def) {try{return parseHex(o.optString(k,def));}catch(Exception e){return parseHex(def);}}
    static JSONObject clean(JSONObject in) throws Exception {
        JSONObject o=new JSONObject();
        o.put("id", in.optInt("id",0));
        o.put("trainer",text(in,"trainer","Treinador",100).trim());
        o.put("title",text(in,"title","Hora de treinar!",150));
        o.put("message",text(in,"message","",4000));
        o.put("emoji",text(in,"emoji","💪",16));
        if(o.getString("trainer").isEmpty()) throw new IllegalArgumentException("Preencha o nome do treinador.");
        String time=in.optString("time","08:00"); LocalTime.parse(time); o.put("time",time);
        String repeat=in.optString("repeat","once");
        if(!repeat.equals("once") && !repeat.equals("daily") && !repeat.equals("weekly")) throw new IllegalArgumentException("Repetição inválida.");
        o.put("repeat",repeat);
        String date=in.optString("date",LocalDate.now().toString()); LocalDate.parse(date); o.put("date",date);
        JSONArray days=new JSONArray(); for(int d=1;d<=7;d++){JSONArray src=in.optJSONArray("days");if(src!=null)for(int j=0;j<src.length();j++)if(src.optInt(j)==d){days.put(d);break;}}
        if(repeat.equals("weekly") && days.length()==0) throw new IllegalArgumentException("Escolha pelo menos um dia da semana.");
        o.put("days",days);
        for(String k:new String[]{"accent","bg","titleColor","textColor"}) {String def=k.equals("bg")?"#182139":k.equals("accent")?"#31D7C3":"#FFFFFF";o.put(k,String.format("#%06X",color(in,k,def)&0xffffff));}
        o.put("size",Math.max(8,Math.min(72,in.optInt("size",16))));
        for(String k:new String[]{"sound","vibrate","bold","enabled"}) o.put(k,in.optBoolean(k,k.equals("enabled")||k.equals("sound")||k.equals("vibrate")));
        o.put("italic",in.optBoolean("italic",false));
        String align=in.optString("align","left");o.put("align",align.equals("center")||align.equals("right")?align:"left");
        String privacy=in.optString("privacy","private");o.put("privacy",privacy.equals("public")||privacy.equals("secret")?privacy:"private");
        o.put("media",sanitizeMedia(in.optJSONArray("media")));
        for(String k:new String[]{"avatar","background"}){JSONObject m=in.optJSONObject(k);JSONArray a=sanitizeMedia(m==null?null:new JSONArray().put(m));if(a.length()>0&&a.getJSONObject(0).optString("mime").startsWith("image/"))o.put(k,a.getJSONObject(0));}
        if(o.getString("message").trim().isEmpty()&&o.getJSONArray("media").length()==0)throw new IllegalArgumentException("Escreva uma mensagem ou adicione uma mídia.");
        for(String k:new String[]{"titleSize","radius","padding","borderWidth","avatarSize","mediaHeight"}){
            int def=k.equals("titleSize")?22:k.equals("radius")?20:k.equals("padding")?20:k.equals("avatarSize")?72:k.equals("mediaHeight")?300:0;
            int min=k.equals("titleSize")?8:k.equals("avatarSize")?32:k.equals("mediaHeight")?80:0;
            int max=k.equals("titleSize")?72:k.equals("radius")?64:k.equals("padding")?48:k.equals("avatarSize")?180:k.equals("mediaHeight")?900:12;
            o.put(k,Math.max(min,Math.min(max,in.optInt(k,def))));
        }
        String font=in.optString("font","system-ui");o.put("font",font.equals("serif")||font.equals("monospace")?font:"system-ui");
        o.put("fit",in.optString("fit").equals("cover")?"cover":"contain");
        o.put("lineHeight",Math.max(1,Math.min(3,in.optDouble("lineHeight",1.5))));
        for(String k:new String[]{"loop","muted","showTime"})o.put(k,in.optBoolean(k,k.equals("showTime")));
        o.put("actionLabel",in.optString("actionLabel","Ver conteúdo"));
        String url=in.optString("actionUrl","").trim();if(!url.isEmpty()){java.net.URI u=new java.net.URI(url);if(!"https".equalsIgnoreCase(u.getScheme())||u.getHost()==null)throw new IllegalArgumentException("O link do botão deve começar com https:// e ter um domínio válido.");}o.put("actionUrl",url);
        String tap=in.optString("tap","card");o.put("tap",java.util.Arrays.asList("trainer","app","gallery","card","none").contains(tap)?tap:"card");
        String tid=in.optString("trainerId","").trim();o.put("trainerId",tid.matches("[A-Za-z0-9_-]{1,64}")?tid:"");
        o.put("trainerMode",in.optString("trainerMode","present").equals("editor")?"editor":"present");
        if(o.getString("tap").equals("trainer")&&o.getString("trainerId").isEmpty())throw new IllegalArgumentException("Escolha o treinador que será aberto ao tocar na notificação.");
        o.put("openLabel",excerpt(in.optString("openLabel","").trim(),40));
        for(String k:new String[]{"fxTrainer","fxTitle","fxMessage"})o.put(k,cleanFx(in.optJSONObject(k)));
        o.put("snooze",Math.max(0,Math.min(1440,in.optInt("snooze",0))));
        o.put("timeout",Math.max(0,Math.min(86400,in.optInt("timeout",0))));
        o.put("ongoing",in.optBoolean("ongoing",false));
        o.put("ownChannel",in.optBoolean("ownChannel",false));
        String imp=in.optString("importance","high");o.put("importance",imp.equals("default")||imp.equals("low")?imp:"high");
        o.put("lastDelivery",in.optLong("lastDelivery",0));
        return o;
    }
    /** Cor por letra de um campo (nome, título ou mensagem). */
    static JSONObject cleanFx(JSONObject f) throws Exception {
        JSONObject src=f==null?new JSONObject():f,o=new JSONObject();
        String mode=src.optString("mode","solid");o.put("mode",LetterFx.validMode(mode)?mode:"solid");
        o.put("c1",String.format("#%06X",color(src,"c1","#2F7BFF")&0xffffff));o.put("c2",String.format("#%06X",color(src,"c2","#FFD93B")&0xffffff));
        JSONArray in=src.optJSONArray("custom"),out=new JSONArray();int last=-1;
        if(in!=null)for(int i=0;i<in.length()&&i<5000;i++){String c=in.optString(i,"");boolean ok=c.matches("#[0-9a-fA-F]{6}");out.put(ok?c.toUpperCase():"");if(ok)last=i;}
        JSONArray trimmed=new JSONArray();for(int i=0;i<=last;i++)trimmed.put(out.get(i));o.put("custom",trimmed);return o;
    }
    static int[] customInts(JSONArray a){int[] r=new int[a==null?0:a.length()];for(int i=0;i<r.length;i++){String c=a.optString(i,"");r[i]=c.matches("#[0-9a-fA-F]{6}")?((int)Long.parseLong(c.substring(1),16))|0xff000000:0;}return r;}
    /** Texto com cor por letra. Sem efeito: texto simples (a cor vem do setTextColor). */
    static CharSequence paint(String prefix,String text,JSONObject fx,int base,int cap){
        boolean plain=fx==null||fx.optString("mode","solid").equals("solid");
        String shown=text.length()>cap?text.substring(0,cap):text;
        if(plain)return prefix+shown;
        android.text.SpannableStringBuilder sb=new android.text.SpannableStringBuilder(prefix);int start=sb.length();sb.append(shown);
        int[] cols=LetterFx.colors(shown,fx.optString("mode"),color(fx,"c1","#2F7BFF"),color(fx,"c2","#FFD93B"),customInts(fx.optJSONArray("custom")),base);
        int runStart=0,runColor=cols.length>0?cols[0]:base,i=0;
        for(int pos=0;pos<shown.length();i++){int cp=shown.codePointAt(pos);int len=Character.charCount(cp);
            if(cols[i]!=runColor){sb.setSpan(new android.text.style.ForegroundColorSpan(runColor),start+runStart,start+pos,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);runStart=pos;runColor=cols[i];}
            pos+=len;}
        if(shown.length()>0)sb.setSpan(new android.text.style.ForegroundColorSpan(runColor),start+runStart,start+shown.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }
    static JSONArray sanitizeMedia(JSONArray src) throws Exception {
        JSONArray out=new JSONArray();if(src==null)return out;
        for(int i=0;i<src.length();i++){JSONObject m=src.optJSONObject(i);if(m==null)continue;String file=m.optString("file"),mime=m.optString("mime");
            if(!file.matches("[a-f0-9-]+\\.(jpg|png|gif|webp|mp4|webm|mov|mp3|wav|ogg|m4a|bin)")||!(mime.startsWith("image/")||mime.startsWith("video/")||mime.startsWith("audio/")))throw new IllegalArgumentException("Mídia inválida. Importe novamente pelo seletor.");
            out.put(new JSONObject().put("file",file).put("mime",mime).put("name",m.optString("name","Mídia")).put("caption",m.optString("caption","")).put("bytes",Math.max(0,m.optLong("bytes",0))));
        }return out;
    }
    static String excerpt(String value,int max){return value.substring(0,Math.min(value.length(),max));}
    public static long next(JSONObject o,long now) {
        ZoneId zone=ZoneId.systemDefault(); LocalTime t=LocalTime.parse(o.optString("time","08:00"));
        if(o.optString("repeat").equals("once")) return LocalDate.parse(o.optString("date")).atTime(t).atZone(zone).toInstant().toEpochMilli();
        LocalDate today=Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
        for(int i=0;i<9;i++) {LocalDate day=today.plusDays(i);boolean ok=o.optString("repeat").equals("daily");JSONArray ds=o.optJSONArray("days");
            if(ds!=null)for(int j=0;j<ds.length();j++)if(ds.optInt(j)==day.getDayOfWeek().getValue())ok=true;
            long at=day.atTime(t).atZone(zone).toInstant().toEpochMilli();if(ok&&at>now)return at;
        } return -1;
    }
    static PendingIntent pending(Context c,int id) {return PendingIntent.getBroadcast(c,id,new Intent(c,ReminderReceiver.class).setAction("com.treinadores.REMINDER").putExtra("id",id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static void cancel(Context c,int id) {c.getSystemService(AlarmManager.class).cancel(pending(c,id));}
    static void schedule(Context c,JSONObject o) {
        int id=o.optInt("id");cancel(c,id);if(!o.optBoolean("enabled",true))return;
        long at=next(o,System.currentTimeMillis()); if(at<=System.currentTimeMillis())return;
        AlarmManager a=c.getSystemService(AlarmManager.class);PendingIntent p=pending(c,id);
        if(exact(c)){try{a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);return;}catch(SecurityException ignored){}}
        a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);
    }
    public static synchronized JSONObject save(Context c,JSONObject raw) throws Exception {
        JSONObject o=clean(raw);JSONArray a=all(c);int id=o.optInt("id"), idx=-1;
        for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optInt("id")==id)idx=i;
        if(idx<0){id=Math.max(1,prefs(c).getInt("sequence",0)+1);if(!prefs(c).edit().putInt("sequence",id).commit())throw new IllegalStateException("Erro ao gerar identificador.");o.put("id",id);}
        if(o.optBoolean("enabled") && o.optString("repeat").equals("once") && next(o,System.currentTimeMillis())<=System.currentTimeMillis())throw new IllegalArgumentException("Escolha uma data e hora futuras.");
        if(idx<0)a.put(o);else a.put(idx,o);persist(c,a);schedule(c,o);
        try{if(o.optBoolean("ownChannel")){ensureChannel(c,o);purgeChannels(c,id,channel(o));}else purgeChannels(c,id,"");}catch(Exception ignored){}
        return o;
    }
    public static synchronized void remove(Context c,int id) throws Exception {
        JSONArray a=all(c), out=new JSONArray();for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optInt("id")!=id)out.put(a.get(i));persist(c,out);prefs(c).edit().remove("display_"+id).remove("snooze_"+id).apply();cancel(c,id);c.getSystemService(AlarmManager.class).cancel(snoozePending(c,id));purgeChannels(c,id,"");c.getSystemService(NotificationManager.class).cancel("trainer",id);
    }
    public static synchronized void reschedule(Context c) {
        JSONArray a=all(c);boolean changed=false;long now=System.currentTimeMillis();
        for(int i=0;i<a.length();i++)try{JSONObject o=a.getJSONObject(i);if(o.optBoolean("enabled")&&o.optString("repeat").equals("once")&&next(o,now)<=now){o.put("enabled",false);o.put("missed",true);changed=true;}schedule(c,o);}catch(Exception ignored){}
        if(changed)persist(c,a);
        rescheduleSnoozes(c);
    }
    public static synchronized void fire(Context c,int id) throws Exception {
        JSONArray a=all(c);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.optInt("id")!=id||!o.optBoolean("enabled"))continue;
            long now=System.currentTimeMillis();if(now-o.optLong("lastDelivery",0)<1000)return;
            o.put("lastDelivery",now);if(o.optString("repeat").equals("once"))o.put("enabled",false);
            persist(c,a);post(c,o,id);schedule(c,o);return;
        }
    }
    /** Canal próprio só existe para lembrete salvo (id > 0): o teste de um rascunho usa o canal comum. */
    static boolean own(JSONObject o) {return o.optBoolean("ownChannel")&&o.optInt("id")>0;}
    public static String channel(JSONObject o) {
        String sv=(o.optBoolean("sound")?"s":"q")+(o.optBoolean("vibrate")?"v":"n");
        if(own(o))return "coach_r"+o.optInt("id")+"_"+o.optString("importance","high").charAt(0)+sv;
        return "coach_v1_"+sv;
    }
    static int importance(JSONObject o){String i=o.optString("importance","high");return i.equals("low")?NotificationManager.IMPORTANCE_LOW:i.equals("default")?NotificationManager.IMPORTANCE_DEFAULT:NotificationManager.IMPORTANCE_HIGH;}
    static void ensureChannel(Context c,JSONObject o) {
        NotificationManager m=c.getSystemService(NotificationManager.class);String id=channel(o);boolean own=own(o);
        if(!own&&m.getNotificationChannel(id)!=null)return;
        String name=own?"🔔 "+excerpt(o.optString("trainer")+" • "+o.optString("title"),60):"Treinadores • "+(o.optBoolean("sound")?"com som":"sem som")+" • "+(o.optBoolean("vibrate")?"vibrar":"sem vibração");
        NotificationChannel ch=new NotificationChannel(id,name,own?importance(o):NotificationManager.IMPORTANCE_HIGH);
        if(own)ch.setDescription("Canal só desta notificação: som, vibração e pop-up daqui não mexem nas outras.");
        if(!o.optBoolean("sound"))ch.setSound(null,null);ch.enableVibration(o.optBoolean("vibrate"));if(o.optBoolean("vibrate"))ch.setVibrationPattern(new long[]{0,200,120,200});
        m.createNotificationChannel(ch); // se já existe, o Android só atualiza o nome; o som escolhido pelo usuário é mantido
    }
    /** Apaga os canais antigos deste lembrete (ao trocar importância/som/vibração nasce um canal novo). */
    static void purgeChannels(Context c,int id,String keep){
        NotificationManager m=c.getSystemService(NotificationManager.class);String prefix="coach_r"+id+"_";
        for(NotificationChannel ch:m.getNotificationChannels())if(ch.getId().startsWith(prefix)&&!ch.getId().equals(keep))m.deleteNotificationChannel(ch.getId());
    }
    static RemoteViews view(Context c,JSONObject o,boolean big) {
        RemoteViews r=new RemoteViews(c.getPackageName(),big?R.layout.reminder_big:R.layout.reminder_small);
        r.setInt(R.id.reminder_card,"setBackgroundColor",color(o,"bg","#182139"));
        r.setInt(R.id.reminder_stripe,"setBackgroundColor",color(o,"accent","#31D7C3"));
        r.setTextViewText(R.id.reminder_trainer,paint(o.optString("emoji")+" ",excerpt(o.optString("trainer"),150),o.optJSONObject("fxTrainer"),color(o,"accent","#31D7C3"),150));r.setTextColor(R.id.reminder_trainer,color(o,"accent","#31D7C3"));
        r.setTextViewText(R.id.reminder_title,paint("",excerpt(o.optString("title"),200),o.optJSONObject("fxTitle"),color(o,"titleColor","#FFFFFF"),200));r.setTextColor(R.id.reminder_title,color(o,"titleColor","#FFFFFF"));
        CharSequence msg=paint("",excerpt(o.optString("message"),4000),o.optJSONObject("fxMessage"),color(o,"textColor","#FFFFFF"),1200);
        android.text.SpannableStringBuilder span=new android.text.SpannableStringBuilder(msg);
        int style=(o.optBoolean("bold")?1:0)|(o.optBoolean("italic")?2:0);span.setSpan(new android.text.style.StyleSpan(style),0,span.length(),android.text.Spanned.SPAN_INCLUSIVE_INCLUSIVE);
        r.setTextViewText(R.id.reminder_message,span);r.setTextColor(R.id.reminder_message,color(o,"textColor","#FFFFFF"));r.setTextViewTextSize(R.id.reminder_message,android.util.TypedValue.COMPLEX_UNIT_SP,Math.min(24,o.optInt("size",16)));
        int gravity=o.optString("align").equals("center")?android.view.Gravity.CENTER:o.optString("align").equals("right")?android.view.Gravity.END:android.view.Gravity.START;
        for(int id:new int[]{R.id.reminder_trainer,R.id.reminder_title,R.id.reminder_message})r.setInt(id,"setGravity",gravity);
        android.graphics.Bitmap avatar=ReminderMedia.image(c,o.optJSONObject("avatar"),96);
        r.setViewVisibility(R.id.reminder_avatar,avatar==null?android.view.View.GONE:android.view.View.VISIBLE);if(avatar!=null)r.setImageViewBitmap(R.id.reminder_avatar,avatar);
        if(big){android.graphics.Bitmap cover=ReminderMedia.image(c,ReminderMedia.firstVisual(o),384);r.setViewVisibility(R.id.reminder_cover,cover==null?android.view.View.GONE:android.view.View.VISIBLE);if(cover!=null)r.setImageViewBitmap(R.id.reminder_cover,cover);
            int count=o.optJSONArray("media")==null?0:o.optJSONArray("media").length();r.setViewVisibility(R.id.reminder_media_hint,count==0?android.view.View.GONE:android.view.View.VISIBLE);r.setTextViewText(R.id.reminder_media_hint,"▶ "+count+" mídia(s) • Toque para abrir");r.setTextColor(R.id.reminder_media_hint,color(o,"accent","#31D7C3"));}
        return r;
    }
    public static JSONObject status(Context c) throws Exception { JSONObject o=new JSONObject().put("notifications",allowed(c)).put("exact",exact(c));JSONObject channels=new JSONObject();NotificationManager m=c.getSystemService(NotificationManager.class);for(String id:new String[]{"coach_v1_sv","coach_v1_sn","coach_v1_qv","coach_v1_qn"}){NotificationChannel ch=m.getNotificationChannel(id);channels.put(id,ch==null||ch.getImportance()!=NotificationManager.IMPORTANCE_NONE);}
        JSONArray all=all(c);for(int i=0;i<all.length();i++){JSONObject r=all.getJSONObject(i);if(!r.optBoolean("ownChannel"))continue;String id=channel(r);NotificationChannel ch=m.getNotificationChannel(id);if(ch!=null)channels.put(id,ch.getImportance()!=NotificationManager.IMPORTANCE_NONE);}
        return o.put("channels",channels);}
    static final int PI=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
    /** O que acontece ao tocar na notificação: cada lembrete tem o seu próprio destino. */
    static PendingIntent openIntent(Context c,JSONObject o,int id) {
        switch(o.optString("tap","card")) {
            case "trainer": return PendingIntent.getActivity(c,id,new Intent(c,EditorActivity.class).setAction("com.treinadores.OPEN_TRAINER."+id).putExtra("openTrainerId",o.optString("trainerId")).putExtra("openMode",o.optString("trainerMode","present")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP),PI);
            case "gallery": return PendingIntent.getActivity(c,id,new Intent(c,EditorActivity.class).setAction("com.treinadores.OPEN_GALLERY."+id).putExtra("openGallery",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP),PI);
            case "app": return PendingIntent.getActivity(c,id,new Intent(c,MainActivity.class).setAction(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),PI);
            case "none": return broadcast(c,id,"com.treinadores.DISMISS",0);
            default: return PendingIntent.getActivity(c,id,new Intent(c,RemindersActivity.class).setAction("com.treinadores.DETAIL."+id).putExtra("detailId",id),PI);
        }
    }
    static PendingIntent broadcast(Context c,int id,String action,int minutes) {return PendingIntent.getBroadcast(c,id,new Intent(c,ReminderReceiver.class).setAction(action).putExtra("id",id).putExtra("minutes",minutes),PI);}
    static String openLabel(JSONObject o) {
        String custom=o.optString("openLabel","").trim();if(!custom.isEmpty())return custom;
        switch(o.optString("tap","card")){case "trainer":return "Abrir treinador";case "gallery":return "Abrir galeria";case "app":return "Abrir app";default:return o.optString("actionLabel","Ver conteúdo");}
    }
    public static void post(Context c,JSONObject o,int id) {
        if(!allowed(c))return;ensureChannel(c,o);
        if(!prefs(c).edit().putString("display_"+id,o.toString()).commit())throw new IllegalStateException("Não foi possível salvar o conteúdo da notificação.");
        PendingIntent open=openIntent(c,o,id);
        int privacy=o.optString("privacy").equals("public")?Notification.VISIBILITY_PUBLIC:o.optString("privacy").equals("secret")?Notification.VISIBILITY_SECRET:Notification.VISIBILITY_PRIVATE;
        Notification publicVersion=new Notification.Builder(c,channel(o)).setSmallIcon(R.drawable.ic_reminder).setContentTitle("Treinadores").setContentText("Você tem um lembrete de treino.").build();
        Notification.Builder b=new Notification.Builder(c,channel(o)).setSmallIcon(R.drawable.ic_reminder).setColor(color(o,"accent","#31D7C3")).setContentTitle(excerpt(o.optString("trainer")+" • "+o.optString("title"),300)).setContentText(excerpt(o.optString("message"),4000)).setCustomContentView(view(c,o,false)).setCustomBigContentView(view(c,o,true)).setStyle(new Notification.DecoratedCustomViewStyle()).setContentIntent(open).setShowWhen(o.optBoolean("showTime",true)).setAutoCancel(!o.optBoolean("ongoing")).setOngoing(o.optBoolean("ongoing")).setVisibility(privacy).setPublicVersion(publicVersion).setCategory(Notification.CATEGORY_REMINDER).setGroup("coach_n"+id);
        if(!o.optString("tap","card").equals("none"))b.addAction(new Notification.Action.Builder(null,excerpt(openLabel(o),40),open).build());
        int snooze=o.optInt("snooze",0);if(snooze>0)b.addAction(new Notification.Action.Builder(null,"Adiar "+(snooze>=60&&snooze%60==0?(snooze/60)+" h":snooze+" min"),broadcast(c,id,"com.treinadores.SNOOZE",snooze)).build());
        if(o.optBoolean("ongoing"))b.addAction(new Notification.Action.Builder(null,"Dispensar",broadcast(c,id,"com.treinadores.DISMISS",0)).build());
        if(o.optInt("timeout",0)>0)b.setTimeoutAfter(o.optInt("timeout")*1000L);
        c.getSystemService(NotificationManager.class).notify("trainer",id,b.build());
    }
    static void setAlarm(Context c,long at,PendingIntent p) {
        AlarmManager a=c.getSystemService(AlarmManager.class);
        if(exact(c)){try{a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);return;}catch(SecurityException ignored){}}
        a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);
    }
    static PendingIntent snoozePending(Context c,int id) {return broadcast(c,id,"com.treinadores.SNOOZE_FIRE",0);}
    /** Botão "Adiar": some agora e volta daqui a N minutos, só este lembrete. */
    public static synchronized void snooze(Context c,int id,int minutes) {
        c.getSystemService(NotificationManager.class).cancel("trainer",id);
        long at=System.currentTimeMillis()+Math.max(1,minutes)*60000L;
        prefs(c).edit().putLong("snooze_"+id,at).commit();setAlarm(c,at,snoozePending(c,id));
    }
    public static synchronized void fireSnooze(Context c,int id) throws Exception {
        prefs(c).edit().remove("snooze_"+id).commit();
        JSONArray a=all(c);for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optInt("id")==id){post(c,a.getJSONObject(i),id);return;}
        String raw=prefs(c).getString("display_"+id,null);if(raw!=null)post(c,new JSONObject(raw),id);
    }
    static void rescheduleSnoozes(Context c) {
        long now=System.currentTimeMillis();
        for(java.util.Map.Entry<String,?> e:prefs(c).getAll().entrySet())if(e.getKey().startsWith("snooze_")&&e.getValue() instanceof Long){
            int id;try{id=Integer.parseInt(e.getKey().substring(7));}catch(Exception bad){continue;}
            long at=(Long)e.getValue();if(at>now)setAlarm(c,at,snoozePending(c,id));else prefs(c).edit().remove(e.getKey()).apply();
        }
    }
    public static void test(Context c,JSONObject in) throws Exception {
        if(!allowed(c))throw new IllegalStateException("Ative a permissão de notificações primeiro.");JSONObject o=clean(in);ensureChannel(c,o);NotificationChannel ch=c.getSystemService(NotificationManager.class).getNotificationChannel(channel(o));if(ch.getImportance()==NotificationManager.IMPORTANCE_NONE)throw new IllegalStateException("Este canal está bloqueado. Abra os canais do Android.");post(c,o,0);
    }
}
