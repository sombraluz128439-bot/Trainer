package com.treinadores.flutuantes;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ContextThemeWrapper;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.function.Consumer;

/** Configura o WebView que carrega o index.html (usado na bolha e na tela cheia). */
public final class Web {
    public static final String URL = "https://appassets.androidplatform.net/assets/index.html";

    /** Fica true quando a tela cheia foi usada; a bolha recarrega para ver os dados novos. */
    public static volatile boolean dirty = false;

    public interface Chooser {
        boolean open(ValueCallback<Uri[]> cb, Intent intent);
    }

    // Faz os downloads (backup .json, PNG) cairem na pasta Downloads.
    private static final String HOOK =
        "(function(){"
        + "if(window.__tfHook)return;window.__tfHook=1;"
        + "function sv(h,n){"
        + "if(h.indexOf('data:')===0){AndroidSave.save(h,n);return;}"
        + "fetch(h).then(function(r){return r.blob();}).then(function(b){"
        + "var f=new FileReader();f.onload=function(){AndroidSave.save(f.result,n);};f.readAsDataURL(b);});"
        + "}"
        + "window.__tfSave=sv;"
        + "var oc=HTMLAnchorElement.prototype.click;"
        + "HTMLAnchorElement.prototype.click=function(){"
        + "if(this.hasAttribute('download')&&/^(data|blob):/.test(this.href)){"
        + "sv(this.href,this.getAttribute('download')||'arquivo');return;}"
        + "return oc.apply(this,arguments);};"
        + "})();";

    public static class ReminderLauncher {
        private final Context ctx;
        ReminderLauncher(Context c) { ctx = c; }
        @JavascriptInterface public void open() {
            new Handler(Looper.getMainLooper()).post(() -> {
                Intent i = new Intent(ctx, RemindersActivity.class);
                if (!(ctx instanceof Activity)) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
            });
        }
    }
    private Web() {}

    public static void setup(final Context ctx, final WebView wv, final Chooser chooser) {
        setup(ctx, wv, chooser, null);
    }

    /** onDead: o que fazer se o processo que desenha a pagina cair (ex.: pouca memoria). */
    @SuppressLint("SetJavaScriptEnabled")
    public static void setup(final Context ctx, final WebView wv, final Chooser chooser, final Runnable onDead) {
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        wv.getSettings().setMediaPlaybackRequiresUserGesture(false);
        wv.getSettings().setSupportZoom(false);
        wv.setBackgroundColor(0xFF0D0F1A);

        wv.addJavascriptInterface(new ReminderLauncher(ctx), "AndroidReminders");
        wv.addJavascriptInterface(new SaveBridge(ctx.getApplicationContext()), "AndroidSave");
        wv.addJavascriptInterface(TtsBridge.get(ctx), "AndroidTTS");
        wv.getSettings().setAllowFileAccess(false);
        wv.getSettings().setAllowContentAccess(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(ctx.getApplicationContext()))
            .build();

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                WebResourceResponse local = loader.shouldInterceptRequest(r.getUrl());
                if (local != null) return local;
                String scheme = r.getUrl().getScheme();
                if ("http".equals(scheme) || "https".equals(scheme))
                    return new WebResourceResponse("text/plain", "UTF-8", 403, "Offline only", java.util.Collections.emptyMap(), new java.io.ByteArrayInputStream(new byte[0]));
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !"appassets.androidplatform.net".equals(r.getUrl().getHost());
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(HOOK, null);
            }

            // Sem isto, se o processo da pagina cair (memoria, muitos videos) o app INTEIRO fecha.
            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                if (onDead != null) {
                    new Handler(Looper.getMainLooper()).post(onDead);
                }
                return true;
            }
        });

        wv.setDownloadListener((url, ua, cd, mime, len) -> {
            if (url.startsWith("blob:")) {
                wv.evaluateJavascript("__tfSave('" + url + "','arquivo')", null);
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String u, String m, final JsResult r) {
                dlg(v.getContext(), m, null, t -> r.confirm(), null);
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String u, String m, final JsResult r) {
                dlg(v.getContext(), m, null, t -> r.confirm(), () -> r.cancel());
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String u, String m, String def, final JsPromptResult r) {
                dlg(v.getContext(), m, def == null ? "" : def, t -> r.confirm(t), () -> r.cancel());
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null && chooser.open(cb, p.createIntent())) {
                    return true;
                }
                cb.onReceiveValue(null);
                Toast.makeText(ctx, "Para escolher arquivos, use \"Abrir treinadores em tela cheia\" no app.",
                    Toast.LENGTH_LONG).show();
                return true;
            }
        });
    }

    /** Caixa de dialogo (alert/confirm/prompt) que tambem funciona por cima de outros apps. */
    private static void dlg(Context ctx, String msg, String def, final Consumer<String> yes, final Runnable no) {
        Context themed = new ContextThemeWrapper(ctx, android.R.style.Theme_Material_Dialog_Alert);
        final EditText input = def == null ? null : new EditText(themed);
        if (input != null) {
            input.setText(def);
        }
        AlertDialog.Builder b = new AlertDialog.Builder(themed).setMessage(msg == null ? "" : msg);
        if (input != null) {
            b.setView(input);
        }
        b.setPositiveButton("OK", (d, w) -> yes.accept(input == null ? "" : input.getText().toString()));
        if (no != null) {
            b.setNegativeButton("Cancelar", (d, w) -> no.run());
        }
        b.setOnCancelListener(d -> {
            if (no != null) {
                no.run();
            } else {
                yes.accept("");
            }
        });
        AlertDialog dialog = b.create();
        if (!(ctx instanceof Activity)) {
            dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        }
        dialog.show();
    }

    /** Salva arquivos gerados pelo HTML (backup, PNG) na pasta Downloads. */
    public static class SaveBridge {
        private final Context ctx;

        SaveBridge(Context c) {
            ctx = c;
        }

        @JavascriptInterface
        public String windowSettings() {
            JSONObject result = new JSONObject();
            android.content.SharedPreferences p = ctx.getSharedPreferences("bolha", 0);
            try {
                for (String key : new String[]{"bx", "by", "px", "py", "pw", "ph", "size"}) {
                    if (p.contains(key)) result.put(key, p.getInt(key, 0));
                }
                result.put("dim", p.getBoolean("dim", false));
            } catch (Exception ignored) {}
            return result.toString();
        }

        /** Chamado pelo index.html: cores da moldura da janela flutuante (acompanham o tema / "Visual"). */
        @JavascriptInterface
        public void setWindowTheme(String frame, String bg, String bar, String txt, int espDp) {
            android.content.SharedPreferences.Editor ed = ctx.getSharedPreferences("bolha", 0).edit();
            ed.putInt("tFrame", Tema.parse(frame, Tema.FRAME));
            ed.putInt("tBg", Tema.parse(bg, Tema.BG));
            ed.putInt("tBar", Tema.parse(bar, Tema.BAR));
            ed.putInt("tTxt", Tema.parse(txt, Tema.TXT));
            ed.putInt("tEsp", Math.max(1, Math.min(8, espDp)));
            ed.apply();
            new Handler(Looper.getMainLooper()).post(() -> {
                if (BubbleService.inst != null) BubbleService.inst.applyTheme();
            });
        }

        @JavascriptInterface
        public void restoreWindowSettings(String json) {
            try {
                JSONObject data = new JSONObject(json);
                android.content.SharedPreferences.Editor ed = ctx.getSharedPreferences("bolha", 0).edit();
                // Campos opcionais: backups antigos continuam funcionando.
                for (String key : new String[]{"bx", "by", "px", "py", "pw", "ph", "size"}) {
                    if (data.has(key)) ed.putInt(key, Math.max(0, Math.min(20000, data.getInt(key))));
                }
                if (data.has("dim")) ed.putBoolean("dim", data.getBoolean("dim"));
                ed.apply();
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (BubbleService.inst != null) BubbleService.inst.reloadGeometry();
                });
            } catch (Exception ignored) { say("Não consegui restaurar os ajustes da janela."); }
        }

        @JavascriptInterface
        public void save(String dataUrl, String name) {
            try {
                int comma = dataUrl.indexOf(',');
                String meta = dataUrl.substring(5, comma);
                String mime = meta.contains(";") ? meta.substring(0, meta.indexOf(';')) : meta;
                if (mime.isEmpty()) {
                    mime = "application/octet-stream";
                }
                String raw = dataUrl.substring(comma + 1);
                byte[] bytes = meta.contains("base64")
                    ? Base64.decode(raw, Base64.DEFAULT)
                    : Uri.decode(raw).getBytes(StandardCharsets.UTF_8);

                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) {
                    throw new Exception("sem destino");
                }
                try (OutputStream os = ctx.getContentResolver().openOutputStream(uri)) {
                    os.write(bytes);
                }
                say("Salvo em Downloads: " + name);
            } catch (Exception e) {
                say("Não consegui salvar: " + e.getMessage());
            }
        }

        private void say(final String t) {
            new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(ctx, t, Toast.LENGTH_LONG).show());
        }
    }
}
