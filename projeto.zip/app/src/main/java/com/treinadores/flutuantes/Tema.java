package com.treinadores.flutuantes;

import android.content.SharedPreferences;

/**
 * Cores da moldura da janela flutuante e da bolha.
 * Elas vem do tema do app (index.html: botao "Visual" / paletas) e ficam guardadas em "bolha".
 * Os valores padrao sao as cores de antes (ciano + azul-marinho), entao nada muda ate voce personalizar.
 */
final class Tema {
    static final int FRAME = 0xFF00F0FF;
    static final int BG = 0xFF0D0F1A;
    static final int BAR = 0xFF171A2E;
    static final int TXT = 0xFFEEF0FF;

    int frame = FRAME;
    int bg = BG;
    int bar = BAR;
    int txt = TXT;
    int espDp = 2;

    static Tema load(SharedPreferences p) {
        Tema t = new Tema();
        t.frame = p.getInt("tFrame", FRAME);
        t.bg = p.getInt("tBg", BG);
        t.bar = p.getInt("tBar", BAR);
        t.txt = p.getInt("tTxt", TXT);
        t.espDp = Math.max(1, Math.min(8, p.getInt("tEsp", 2)));
        return t;
    }

    /** Converte "#rrggbb" numa cor opaca; se vier algo invalido, devolve o padrao. */
    static int parse(String s, int def) {
        try {
            if (s == null) {
                return def;
            }
            String h = s.trim();
            if (h.length() != 7 || h.charAt(0) != '#') {
                return def;
            }
            return 0xFF000000 | Integer.parseInt(h.substring(1), 16);
        } catch (Exception e) {
            return def;
        }
    }

    /** Mesma cor com outra transparencia (a = 0..255). */
    static int alpha(int c, int a) {
        return (a << 24) | (c & 0x00FFFFFF);
    }
}
