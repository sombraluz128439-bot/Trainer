package com.treinadores.flutuantes;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Locale;
import java.util.Set;

/** Apenas vozes locais instaladas. Arquivos MP4 não são modelos TTS. */
public class TtsBridge {
    private static TtsBridge inst;
    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private volatile boolean ready;
    private boolean settingsOpened;
    public static synchronized TtsBridge get(Context c) {
        if (inst == null) inst = new TtsBridge(c.getApplicationContext());
        return inst;
    }
    public static synchronized void stopIfCreated() { if(inst!=null) inst.stop(); }
    public static synchronized void refreshIfNeeded() {
        if(inst!=null && inst.settingsOpened) {
            inst.settingsOpened=false;
            inst.main.post(inst::initialize);
        }
    }
    private TtsBridge(Context c) { app=c;main.post(this::initialize); }
    private void initialize() {
        ready=false;
        if(tts!=null) {tts.stop();tts.shutdown();}
        tts=new TextToSpeech(app,status->{ready=status==TextToSpeech.SUCCESS;});
    }
    private boolean local(Voice v) {
        return v!=null && !v.isNetworkConnectionRequired()
            && (v.getFeatures()==null || !v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED));
    }
    @JavascriptInterface public String voices() {
        if(settingsOpened) {refreshIfNeeded();return "[]";}
        JSONArray out=new JSONArray();
        if(!ready)return out.toString();
        try {
            Set<Voice> all=tts.getVoices();
            if(all!=null) {
                ArrayList<Voice> sorted=new ArrayList<>(all);sorted.sort(Comparator.comparing(Voice::getName));
                for(Voice v:sorted) if(local(v)) {
                    JSONObject o=new JSONObject();o.put("name",v.getName());o.put("lang",v.getLocale().toLanguageTag());
                    o.put("voiceURI",v.getName());o.put("localService",true);o.put("default",false);out.put(o);
                }
            }
        }catch(Exception ignored){}
        return out.toString();
    }
    private Voice choose(String name,String lang,boolean explicit) {
        Set<Voice> all=tts.getVoices();if(all==null)return null;
        for(Voice v:all)if(v.getName().equals(name))return local(v)?v:null;
        if(explicit)return null;
        Locale locale=Locale.forLanguageTag(lang==null||lang.isEmpty()?"pt-BR":lang);
        for(Voice v:all)if(local(v)&&v.getLocale().equals(locale))return v;
        for(Voice v:all)if(local(v)&&v.getLocale().getLanguage().equals(locale.getLanguage()))return v;
        return null;
    }
    @JavascriptInterface public synchronized String speakOffline(String text,String name,double rate,double pitch) {
        if(!ready)return "O motor de voz ainda não está pronto. Aguarde e tente novamente.";
        if(text==null||text.trim().isEmpty())return "Digite uma frase para falar.";
        if(name==null||name.isEmpty())return "Escolha uma voz offline para este personagem em Ajustes.";
        try{return play(text,choose(name,"pt-BR",true),rate,pitch);}catch(Exception e){return "Falha no motor de voz local.";}
    }
    private String play(String text,Voice v,double rate,double pitch) {
        if(!local(v))return "Voz offline não disponível. Instale os dados de voz no Android e atualize a lista.";
        if(text.length()>TextToSpeech.getMaxSpeechInputLength())return "Frase muito longa. Divida o texto em partes menores.";
        if(tts.setVoice(v)==TextToSpeech.ERROR)return "O motor não conseguiu carregar esta voz offline.";
        tts.setSpeechRate((float)Math.max(.1,Math.min(3,rate)));
        tts.setPitch((float)Math.max(.1,Math.min(2,pitch)));
        int r=tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"tf-local");
        return r==TextToSpeech.ERROR?"O motor não conseguiu falar. Confira os dados offline instalados.":"ok";
    }
    @JavascriptInterface public synchronized void speak(String text,String lang,double rate,double pitch,String name) {
        if(!ready||text==null||text.trim().isEmpty())return;
        try{String result=play(text,choose(name,lang,false),rate,pitch);if(!"ok".equals(result))main.post(()->Toast.makeText(app,result,Toast.LENGTH_LONG).show());}catch(Exception ignored){}
    }
    @JavascriptInterface public synchronized void stop() {try{if(tts!=null)tts.stop();}catch(Exception ignored){} }
    @JavascriptInterface public void openSettings() {
        settingsOpened=true;
        main.post(()->{
            try {app.startActivity(new Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
            catch(Exception e){app.startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
        });
    }
}
