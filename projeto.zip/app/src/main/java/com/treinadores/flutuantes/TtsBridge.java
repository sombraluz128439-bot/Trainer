package com.treinadores.flutuantes;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Ponte entre o JavaScript do HTML e a voz (TextToSpeech) do Android. */
public class TtsBridge {
    private static TtsBridge inst;
    private TextToSpeech tts;
    private volatile boolean ready = false;

    public static synchronized TtsBridge get(Context c) {
        if (inst == null) {
            inst = new TtsBridge(c.getApplicationContext());
        }
        return inst;
    }

    /** Para de falar sem criar o motor de voz so para isso (usado ao desligar a bolha). */
    public static synchronized void stopIfCreated() {
        if (inst != null) {
            inst.stop();
        }
    }

    private TtsBridge(Context app) {
        tts = new TextToSpeech(app, status -> {
            ready = (status == TextToSpeech.SUCCESS);
            if (ready) {
                try {
                    tts.setLanguage(new Locale("pt", "BR"));
                } catch (Exception e) {
                    // ignora
                }
            }
        });
    }

    @JavascriptInterface
    public String voices() {
        JSONArray arr = new JSONArray();
        try {
            Set<Voice> vs = tts.getVoices();
            if (vs != null) {
                List<Voice> l = new ArrayList<>(vs);
                Collections.sort(l, (a, b) -> a.getName().compareTo(b.getName()));
                for (Voice v : l) {
                    JSONObject o = new JSONObject();
                    o.put("name", v.getName());
                    o.put("lang", v.getLocale().toLanguageTag());
                    o.put("voiceURI", v.getName());
                    o.put("localService", !v.isNetworkConnectionRequired());
                    o.put("default", false);
                    arr.put(o);
                }
            }
        } catch (Exception e) {
            // ignora
        }
        return arr.toString();
    }

    @JavascriptInterface
    public void speak(String text, String lang, double rate, double pitch, String voice) {
        if (!ready || text == null || text.trim().isEmpty()) {
            return;
        }
        try {
            Voice chosen = null;
            if (voice != null && !voice.isEmpty()) {
                Set<Voice> vs = tts.getVoices();
                if (vs != null) {
                    for (Voice v : vs) {
                        if (v.getName().equals(voice)) {
                            chosen = v;
                            break;
                        }
                    }
                }
            }
            if (chosen != null) {
                tts.setVoice(chosen);
            } else {
                tts.setLanguage(lang != null && !lang.isEmpty() ? Locale.forLanguageTag(lang) : new Locale("pt", "BR"));
            }
            tts.setSpeechRate((float) Math.max(0.1, Math.min(3.0, rate)));
            tts.setPitch((float) Math.max(0.1, Math.min(2.0, pitch)));
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tf");
        } catch (Exception e) {
            // ignora
        }
    }

    @JavascriptInterface
    public void stop() {
        try {
            tts.stop();
        } catch (Exception e) {
            // ignora
        }
    }
}
