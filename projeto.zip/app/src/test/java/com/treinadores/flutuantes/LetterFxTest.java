package com.treinadores.flutuantes;
import org.junit.Test;
import static org.junit.Assert.*;

public class LetterFxTest {
    static final int A=0xff2f7bff, B=0xffffd93b, BASE=0xffffffff;
    @Test public void solidUsesBase() {for(int c:LetterFx.colors("Kitana","solid",A,B,null,BASE))assertEquals(BASE,c);}
    @Test public void alternatesLetterByLetter() {int[] c=LetterFx.colors("Kita","alt",A,B,null,BASE);assertArrayEquals(new int[]{A,B,A,B},c);}
    @Test public void spacesDoNotAdvanceAlternation() {int[] c=LetterFx.colors("a b","alt",A,B,null,BASE);assertEquals(A,c[0]);assertEquals(BASE,c[1]);assertEquals(B,c[2]);}
    @Test public void alternatesWordByWord() {int[] c=LetterFx.colors("ab cd ef","words",A,B,null,BASE);assertArrayEquals(new int[]{A,A,BASE,B,B,BASE,A,A},c);}
    @Test public void gradientGoesFromFirstToSecond() {int[] c=LetterFx.colors("abcde","grad",A,B,null,BASE);assertEquals(A,c[0]);assertEquals(B,c[4]);assertNotEquals(c[0],c[2]);}
    @Test public void singleLetterGradientUsesFirst() {assertEquals(A,LetterFx.colors("x","grad",A,B,null,BASE)[0]);}
    @Test public void rainbowStartsRedAndVaries() {int[] c=LetterFx.colors("abcdef","rainbow",A,B,null,BASE);assertEquals(0xffff2626,c[0]);assertNotEquals(c[0],c[3]);}
    @Test public void customHonoursEachLetterAndZeroMeansBase() {int[] c=LetterFx.colors("abc","custom",A,B,new int[]{0xffff0000,0,0xff00ff00},BASE);assertArrayEquals(new int[]{0xffff0000,BASE,0xff00ff00},c);}
    @Test public void customShorterThanTextFallsBackToBase() {int[] c=LetterFx.colors("abcd","custom",A,B,new int[]{0xffff0000},BASE);assertEquals(0xffff0000,c[0]);assertEquals(BASE,c[3]);}
    @Test public void emojiCountsAsOneLetter() {assertEquals(3,LetterFx.colors("a\uD83D\uDCAAb","alt",A,B,null,BASE).length);}
    @Test public void emptyText() {assertEquals(0,LetterFx.colors("","alt",A,B,null,BASE).length);}
    @Test public void validModes() {assertTrue(LetterFx.validMode("custom"));assertFalse(LetterFx.validMode("hack"));}
}
